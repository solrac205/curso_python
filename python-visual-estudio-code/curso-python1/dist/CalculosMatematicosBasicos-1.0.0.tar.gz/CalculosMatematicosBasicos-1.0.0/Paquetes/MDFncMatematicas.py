def sumar(Valor1, Valor2):
    Suma=0
    Suma=Valor1 + Valor2
    print("El resultado de la suma es: ", Suma)

def resta(Valor1, Valor2):
    Resta=0
    Resta= Valor1 - Valor2
    print("El resultado de la resta es: ", Resta)

def Multiplica(Valor1, Valor2):
    Multi=0
    Multi=Valor1*Valor2
    print("El resultado de la Multiplicasión es: ", Multi)
    

