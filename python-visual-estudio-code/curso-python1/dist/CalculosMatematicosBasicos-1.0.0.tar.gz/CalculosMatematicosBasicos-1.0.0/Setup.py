#print("******************************************************")
#print("Curso No. 36 ... Instalacion de Paquetes..." ) 
#print("******************************************************")
from setuptools import setup

setup(name="CalculosMatematicosBasicos",
      version="1.0.0",
      description="Paquete de prueba calculos básicos",
      author="Carlos F. Ramírez Abdalla",
      author_email="carlos_205ram@hotmail.com",
      url="www.CRAneoSoftware.com",
      packages=["Paquetes"]
    )

#Al concluir con lo anterior el archivo se guarda.
#ya guardado el archivo se procede a ejecutar en shell
#la instruccion:
#    python setup.py sdist [enter]    